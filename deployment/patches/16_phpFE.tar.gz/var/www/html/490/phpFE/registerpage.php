<?php
   // ini_set('display_startup_errors', true);
   // error_reporting(E_ALL);
   // ini_set('display_errors', true);
   include('./registrationForm.php');
   echo "hello ";
   session_start();
   $_GET['username'];
   echo $_SESSION['username'];
?>

<html>

<head>
  
 
</head>

<body>
  HELLO
     
</body>

</html>


