<!-- Header -->
  <header class="w3-container" style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> My Match Making</b></h5>
  </header> 
         
  <!--<form  class="form-inline" method="POST" action="matchmaking.php">-->

  <div class="w3-container">
       <h3> When you hit start match below you will be randomly paired up with another team and you will vs them </h3>
       <h3> The results will be displayed on the next page </h3>
       <h3> Your Current Team Efficiency: 444 </h3>
       <button class="btn btn-lg btn-primary btn-block btn-login" type="submit" ="submit" id="submit">Start Match</button>
  </div>
