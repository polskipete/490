<?php


     session_start();
     $_SESSION['name'] = 'John Snow';
     $_SESSION['username'] = 'JSnow03';
     $_SESSION['win'] = 3;
     $_SESSION['loss'] = 4;
     $_SESSION['draw'] = 3;
?>
