
<!-- Trigger/Open The Modal -->
<button id="myBtn">Open Modal</button>
<h2> weeeeeeb </h2>
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <p>Some text in the Modal..</p>
  </div>

</div>

