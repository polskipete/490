<?php
<<<<<<< HEAD
	phpinfo();
=======
phpinfo();
>>>>>>> peterMarc_buildTeamFunction
?>
