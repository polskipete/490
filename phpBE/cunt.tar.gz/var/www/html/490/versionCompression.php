#!/usr/bin/php
<?php

	$version = "cunt";
	$compression = "tar -czvf cunt.tar.gz /var/www/html/490";
	function createTAR()
	{
		exec($compression);
	}

?>
