<?php


     session_start();
     $_SESSION['name'] = 'John Snow';
     $_SESSION['username'] = 'JSnow03';

?>
